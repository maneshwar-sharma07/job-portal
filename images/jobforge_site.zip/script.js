const jobs = [
  { id: 1, title: "UPSC Civil Services - Assistant", company: "Govt India", location: "New Delhi", desc: "Administrative services role." },
  { id: 2, title: "Banking Associate", company: "Union Bank", location: "Mumbai", desc: "Customer operations." },
  { id: 3, title: "Railway Technician", company: "Indian Railways", location: "Bhopal", desc: "Technical duties." },
  { id: 4, title: "Frontend Developer", company: "StartupX", location: "Bengaluru", desc: "React developer." },
];

const jobsList = document.getElementById('jobsList');

function renderJobs(list){
  jobsList.innerHTML = '';
  list.forEach(job=>{
    const card=document.createElement('div');
    card.className='job-card';
    card.innerHTML = `<h3>${job.title}</h3>
      <p><strong>${job.company}</strong> • ${job.location}</p>
      <p>${job.desc}</p>`;
    jobsList.appendChild(card);
  });
}

renderJobs(jobs);
document.getElementById('year').textContent=new Date().getFullYear();
